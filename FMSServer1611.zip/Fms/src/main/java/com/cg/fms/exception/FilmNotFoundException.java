package com.cg.fms.exception;

public class FilmNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1891150692109445233L;

	public FilmNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FilmNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public FilmNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public FilmNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FilmNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
