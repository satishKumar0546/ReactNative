package com.cg.fms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fms.dao.ActorDaoJPA;
import com.cg.fms.dao.AlbumDaoJPA;
import com.cg.fms.dao.FilmDaoJPA;
import com.cg.fms.dao.LanguageDaoJPA;
import com.cg.fms.domain.Actor;
import com.cg.fms.domain.Film;
import com.cg.fms.domain.Language;
import com.cg.fms.domain.Status;
import com.cg.fms.exception.ActorNotFoundException;
import com.cg.fms.exception.DuplicateFilmException;
import com.cg.fms.exception.FilmNotFoundException;
import com.cg.fms.exception.SearchException;

@Service
public class FilmServiceImpl implements FilmService {
	private FilmDaoJPA repo;
	private ActorDaoJPA actorRepo;
	private LanguageDaoJPA langRepo;
	private AlbumDaoJPA albumRepo;
	@Autowired
	public FilmServiceImpl(FilmDaoJPA repo, ActorDaoJPA actorRepo, LanguageDaoJPA langRepo, AlbumDaoJPA albumRepo){
		this.repo = repo;
		this.actorRepo = actorRepo;
		this.langRepo = langRepo;
		this.albumRepo = albumRepo;
	}

	@Override
	public Status addFilm(Film film) throws DuplicateFilmException {
		if(film.getTitle().equals("") || film.getDescription().equals("") || 
				film.getReleaseYear().equals("") || film.getSpecialFeature().equals("") || 
				film.getCategory().equals("") || film.getRating().equals("")){
			return new Status("Failure");
		}

		if(!(film.getRating().equals("PG") || film.getRating().equals("R") || film.getRating().equals("G"))){
			return new Status("Failure");
		}
		
		if(repo.findByTitleAndReleaseYearAndDeleteDateIsNull(film.getTitle(), film.getReleaseYear())!=null){
			throw new DuplicateFilmException();
		}
		
		Language language = langRepo.findByLanguageName(film.getLanguage().getLanguageName());
			
		if(language == null){
			langRepo.save(film.getLanguage());
			film.setLanguage(langRepo.findByLanguageName(film.getLanguage().getLanguageName()));
		}
		if(language!=null){
			film.setLanguage(language);
		}
		
		albumRepo.save(film.getAlbum());
		film.setAlbum(albumRepo.findByAlbumName(film.getAlbum().getAlbumName()));
		

		boolean ifAdded = repo.save(film) != null;

		if(ifAdded) {
			return new Status("Success");
		}
		else {
			throw new DuplicateFilmException(); 
		}
	}

	@Override
	public Status modifyFilm(Film film) throws FilmNotFoundException {
		if(!(film.getRating().equals("PG") || film.getRating().equals("R") || film.getRating().equals("G"))){
			return new Status("Failure");
		}
		List<Actor> actors=film.getActors();
		for(Actor a : actors) {
			if(a.getFirstName().trim().equals("") || a.getLastName().trim().equals("")){
				return new Status("Failure");
			}
		}

		Film foundFilm=repo.findByfilmId(film.getFilmId());
		if(foundFilm == null){
			throw new FilmNotFoundException();
		}
		
		foundFilm.setActors(film.getActors());
		foundFilm.getAlbum().setPictures(film.getAlbum().getPictures());
		foundFilm.setRating(film.getRating());
		foundFilm.setDescription(film.getDescription());
		repo.save(foundFilm);

		return new Status("Success");
	}

	@Override
	public Status removeFilm(int id) throws FilmNotFoundException {
		Film film = repo.findOne(id);
		if(film == null){
			throw new FilmNotFoundException();
		}
		else{
			film.setDeleteDate(new java.sql.Date(new java.util.Date().getTime()));
			repo.save(film);
			return new Status("Success");
		}	
	}

	@Override
	public List<Film> searchFilmByTitle(String title) throws SearchException, FilmNotFoundException {
		if(title.trim().equals("")){
			throw new SearchException("Field title cannot be blank");
		}
		List<Film> foundFilms=repo.findByTitleStartingWithAndDeleteDateIsNull(title);
		if(foundFilms.size()==0){
			throw new FilmNotFoundException("Desired film not found");
		}
		return foundFilms;
	}

	@Override
	public List<Film> searchFilmByCategory(String categoryName) throws SearchException, FilmNotFoundException {
		if(categoryName.trim().equals("")){
			throw new SearchException("Field category cannot be blank");
		}
		try{
			Integer.parseInt(categoryName);
		}catch(NumberFormatException e){
			List<Film> foundFilms=repo.findByFilmCategoryAndDeleteDateIsNull(categoryName);
			if(foundFilms.size()==0){
				throw new FilmNotFoundException("No movie found for stated category");
			}
			return foundFilms;
		}
		throw new SearchException("Invalid category or category name");
	}

	@Override
	public List<Film> searchFilmByLanguage(String languageName) throws SearchException, FilmNotFoundException {
		if(languageName.trim().equals("")){
			throw new SearchException("Field language cannot be blank");
		}
		try{
			Integer.parseInt(languageName);
		}catch(NumberFormatException e){
			List<Film> foundFilms = repo.findByLanguageAndDeleteDateIsNull(langRepo.findByLanguageName(languageName));
			if(foundFilms.size()==0){
				throw new FilmNotFoundException("No movie found for stated language");
			}
			return foundFilms;
		}
		throw new SearchException("Invalid language or language name");
	}

	@Override
	public List<Film> searchFilmByRating(String rating) throws SearchException, FilmNotFoundException {
		rating=rating.trim();

		if(rating.equals("")){
			throw new SearchException("Field rating cannot be blank");
		}

		if(!(rating.equals("PG") || rating.equals("R") || rating.equals("G"))){
			throw new SearchException("Invalid rating");
		}

		List<Film> foundFilms=repo.findByRatingAndDeleteDateIsNull(rating);
		if(foundFilms.size()==0){
			throw new FilmNotFoundException("No movie found for stated rating");
		}
		return foundFilms;
	}

	@Override
	public List<Film> searchFilmByReleaseYear(String releaseYear) throws SearchException, FilmNotFoundException {
		if(releaseYear.trim().equals("")){
			throw new SearchException("Field release year cannot be blank");
		}
		try{
			Integer.parseInt(releaseYear);
		}catch(NumberFormatException e){

			throw new SearchException("Invalid release year");	
		}

		List<Film> foundFilms=repo.findByReleaseYearAndDeleteDateIsNull(releaseYear);
		if(foundFilms.size()==0){
			throw new FilmNotFoundException("No movie found for stated release year");
		}
		return foundFilms;
	}
	@Override
	public List<Film> findAllFilms() {
		return repo.findAll();
	}
	@Override
	public Film findOne(int id) {
		return repo.findByfilmId(id);
	}

	@Override
	public List<Film> findByActor(String name) {
		System.out.println(name);
		String[] splitName = name.split(" ");
		List<Actor> foundActors = new ArrayList<Actor>();
		if(splitName.length == 1){
			foundActors.addAll(actorRepo.findByFirstNameStartingWithOrLastNameLike(splitName[0], ""));
			foundActors.addAll(actorRepo.findByFirstNameLikeOrLastNameStartingWith("", splitName[0]));
		}
		else if(splitName.length == 2){
			foundActors = actorRepo.findByFirstNameStartingWithOrLastNameLike(splitName[0], splitName[1]);
		}
		if(foundActors!=null){
			return repo.findDistinctByActorsIn(foundActors);
		}
		throw new ActorNotFoundException();
	}
}
