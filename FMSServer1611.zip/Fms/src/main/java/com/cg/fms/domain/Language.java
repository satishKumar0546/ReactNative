package com.cg.fms.domain;




import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity
public class Language {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int languageId;
	
	String languageName;
	
	public int getLanguageId() {
		return languageId;
	}

	public void setLanguageId(int languageId) {
		this.languageId = languageId;
	}

	public String getLanguageName() {
		return languageName;
	}

	public void setLanguageName(String languageName) {
		this.languageName = languageName;
	}
	
	@Override
	public boolean equals(Object o){
		Language l=(Language)o;
		return languageName.equalsIgnoreCase(l.languageName);
	}
	
	@Override
	public int hashCode(){
		return languageName.hashCode();
	}
}
