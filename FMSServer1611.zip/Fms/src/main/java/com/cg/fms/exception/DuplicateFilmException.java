package com.cg.fms.exception;

public class DuplicateFilmException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1578940161920929589L;

	public DuplicateFilmException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DuplicateFilmException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public DuplicateFilmException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public DuplicateFilmException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DuplicateFilmException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
