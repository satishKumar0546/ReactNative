package com.cg.fms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fms.dao.ActorDaoJPA;
import com.cg.fms.domain.Actor;
import com.cg.fms.domain.Status;

@Service
public class ActorServiceImpl implements ActorService {
	ActorDaoJPA repo;

	@Autowired
	public ActorServiceImpl(ActorDaoJPA repo){
		this.repo = repo;
	}

	@Override
	public Status modifyActor(Actor actor) {
		Actor foundActor = repo.findOne(actor.getActorId());
		foundActor.setPictureUrl(actor.getPictureUrl());
		repo.save(foundActor);
		return new Status("Success");
	}

	@Override
	public List<Actor> findActors(String firstName, String lastName) {
		return repo.findByFirstNameStartingWithOrLastNameLike(firstName, lastName);
	}

	@Override
	public Status addActor(Actor actor) {
		boolean ifAdded = repo.save(actor) !=null;
		if(ifAdded){
			return new Status("Failure");
		}
		else{
			return new Status("Success");
		}
	}

	@Override
	public List<Actor> findAll() {
		return repo.findAll();
	}

	@Override
	public Actor find(int id) {
		return repo.findOne(id);
	}

	@Override
	public List<Actor> findActorsPrecise(String firstName, String lastName) {
		return repo.findByFirstNameAndLastNameStartingWith(firstName, lastName);
	}
}
