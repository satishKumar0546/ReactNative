package com.cg.fms.service;

import java.util.List;

import com.cg.fms.domain.Film;
import com.cg.fms.domain.Status;
import com.cg.fms.exception.DuplicateFilmException;
import com.cg.fms.exception.FilmNotFoundException;
import com.cg.fms.exception.SearchException;

public interface FilmService {
Status addFilm(Film film) throws DuplicateFilmException;
Status modifyFilm(Film film) throws FilmNotFoundException;
Status removeFilm(int id) throws FilmNotFoundException;
List<Film> searchFilmByTitle(String title) throws SearchException, FilmNotFoundException;
List<Film> searchFilmByCategory(String categoryName)throws SearchException, FilmNotFoundException;
List<Film> searchFilmByLanguage(String languageName)throws SearchException, FilmNotFoundException;
List<Film> searchFilmByRating(String rating)throws SearchException, FilmNotFoundException;
List<Film> searchFilmByReleaseYear(String releaseYear) throws SearchException, FilmNotFoundException;
List<Film> findAllFilms();
Film findOne(int id);
List<Film> findByActor(String name);
}
