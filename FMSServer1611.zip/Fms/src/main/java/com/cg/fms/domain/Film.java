package com.cg.fms.domain;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(uniqueConstraints=@UniqueConstraint(columnNames="album_albumId"))
public class Film {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int filmId;
	public void setDescription(String description) {
		this.description = description;
	}

	private String title;
	@Column(length=10000)
	private String description;
	private String specialFeature;
	@ManyToOne(cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private Language language;
	private Date deleteDate;
	public Date getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}

	public Language getLanguage() {
		return language;
	}

	public void setLanguage(Language language) {
		this.language = language;
	}

	@ManyToMany(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	private List<Actor> actors=new ArrayList<Actor>();
	private String releaseYear;
	private String filmCategory;
	@OneToOne(cascade=CascadeType.MERGE, fetch=FetchType.EAGER)
	private Album album;
	private String rating;
	private String length;
	
	public String getLength() {
		return length;
	}

	public void setLength(String length) {
		this.length = length;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating.trim().toUpperCase();
	}
	public Film () {}

	public Film(String title, String description, String specialFeature, Language language, String releaseYear,
			String filmCategory, String rating, String length) {
		super();
		this.title = title.trim();
		this.description = description.trim();
		this.specialFeature = specialFeature.trim();
		this.language = language;
		this.releaseYear = releaseYear.trim();
		this.filmCategory = filmCategory.trim();
		this.rating = rating.trim().toUpperCase();
		this.length = length;
	}

	@Override
	public String toString() {
		return "Film [filmId=" + filmId + ", title=" + title + ", description=" + description + ", specialFeature="
				+ specialFeature + ", language=" + language + ", actors=" + actors + ", releaseYear=" + releaseYear
				+ ", filmCategory=" + filmCategory + ", album=" + album + ", rating=" + rating + ", length=" + length
				+ "]";
	}

	
	
	public int getFilmId() {
		return filmId;
	}

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}

	public String getSpecialFeature() {
		return specialFeature;
	}

	public List<Actor> getActors() {
		return actors;
	}

	public void setActors(List<Actor> actors) {
		this.actors = actors;
	}

	public String getReleaseYear() {
		return releaseYear;
	}

	public Album getAlbum() {
		return album;
	}

	public void setAlbum(Album album) {
		this.album = album;
	}

	public String getCategory() {
		return this.filmCategory;
	}

	public String getFilmCategory() {
		return filmCategory;
	}

	public void setFilmCategory(String filmCategory) {
		this.filmCategory = filmCategory;
	}
}
