package com.cg.fms.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.fms.domain.Actor;

public interface ActorDaoJPA extends JpaRepository<Actor, Integer> {
	List<Actor> findByFirstNameStartingWithOrLastNameLike(String firstName, String lastName);
	List<Actor> findByFirstNameAndLastNameStartingWith(String firstName, String lastName);
	List<Actor> findByFirstNameLikeOrLastNameStartingWith(String firstName, String lastName);
}
