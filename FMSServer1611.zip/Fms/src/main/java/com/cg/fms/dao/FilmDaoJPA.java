package com.cg.fms.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.fms.domain.Actor;
import com.cg.fms.domain.Film;
import com.cg.fms.domain.Language;

public interface FilmDaoJPA extends JpaRepository<Film, Integer>{
	List<Film> findByTitleStartingWithAndDeleteDateIsNull(String title);
	List<Film> findByReleaseYearAndDeleteDateIsNull(String releaseYear);
	List<Film> findByRatingAndDeleteDateIsNull(String rating);
	List<Film> findByFilmCategoryAndDeleteDateIsNull(String filmCategory);
	List<Film> findByLanguageAndDeleteDateIsNull(Language language);
	List<Film> findDistinctByActorsIn(List<Actor> actors);
	List<Film> findByTitleAndReleaseYearAndDeleteDateIsNull(String title, String releaseYear);
	Film findByfilmId(int id);
}
