package com.cg.fms.domain;

import org.springframework.stereotype.Component;

@Component
public class Status {
	private String description;
	
	public Status(){}
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Status(String description) {
		super();
		this.description = description;
	}
}
