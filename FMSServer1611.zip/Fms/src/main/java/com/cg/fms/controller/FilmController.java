package com.cg.fms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.fms.domain.Actor;
import com.cg.fms.domain.Film;
import com.cg.fms.domain.Status;
import com.cg.fms.service.ActorService;
import com.cg.fms.service.FilmService;

@RestController
public class FilmController {

	@Autowired
	private FilmService service;
	@Autowired
	ActorService actorService;
	
	
	@RequestMapping(value="/", method = RequestMethod.GET)
	public String defaultFunction(){
		return "something";
	}
	
	@RequestMapping(value="/addFilm", method = RequestMethod.POST)
	public Status addFilm(@RequestBody Film film) {
		return service.addFilm(film);
	}
	
	@RequestMapping(value="/findAll" , method = RequestMethod.GET)
	public List<Film> getAllFilms(){
		return service.findAllFilms();
	}
	
	@RequestMapping(value="/findById", method = RequestMethod.GET)
	public Film getFilm(int id){
		return service.findOne(id);
	}
	
	@RequestMapping(value="/findByTitle", method = RequestMethod.GET)
	public List<Film> getFilmByTitle(String title){
		return service.searchFilmByTitle(title);
	}
	
	@RequestMapping(value="/findByReleaseYear", method = RequestMethod.GET)
	public List<Film> getFilmByReleaseYear(String releaseYear){
		return service.searchFilmByReleaseYear(releaseYear);
	}
	
	@RequestMapping(value="/findByRating", method = RequestMethod.GET)
	public List<Film> getFilmByRating(String rating){
		return service.searchFilmByRating(rating);
	}
	
	@RequestMapping(value="/findByCategory", method = RequestMethod.GET)
	public List<Film> getFilmByCategory(String category){
		return service.searchFilmByCategory(category);
	}
	
	@RequestMapping(value="/findByLanguage", method = RequestMethod.GET)
	public List<Film> getFilmByLanguage(String language){
		return service.searchFilmByLanguage(language);
	}
	
	@RequestMapping(value="/removeFilm", method = RequestMethod.GET)
	public Status removeFilm(int id){
		return service.removeFilm(id);
	}
	
	@RequestMapping(value="/findByActor", method = RequestMethod.GET)
	public List<Film> findByActor(String name){
		return service.findByActor(name);
	}
	
	
	@RequestMapping(value = "/findActors", method = RequestMethod.GET)
	public List<Actor> findActors(String firstName, String lastName){
		return actorService.findActors(firstName, lastName);
	}
	
	@RequestMapping(value = "/findActorsPrecise", method = RequestMethod.GET)
	public List<Actor> findActorsPrecise(String firstName, String lastName){
		return actorService.findActorsPrecise(firstName, lastName);
	}
	
	@RequestMapping(value = "/addActor", method = RequestMethod.POST)
	public Status addActor(@RequestBody Actor actor){
		return actorService.addActor(actor);
	}
	
	@RequestMapping(value = "/findAllActors", method = RequestMethod.GET)
	public List<Actor> findAllActors(){
		return actorService.findAll();
	}
	
	@RequestMapping(value = "/findActorById", method = RequestMethod.GET)
	public Actor findOneActor(int id){
		return actorService.find(id);
	}
	
	@RequestMapping(value = "/updateFilm", method = RequestMethod.POST)
	public Status updateFilm(@RequestBody Film film){
		return service.modifyFilm(film);
	}
	
	@RequestMapping(value = "/updateActor", method = RequestMethod.POST)
	public Status updateActor(@RequestBody Actor actor){
		return actorService.modifyActor(actor);
	}
}
