package com.cg.fms.dao;



import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.fms.domain.Album;

public interface AlbumDaoJPA extends JpaRepository<Album, Integer> {
	Album findByAlbumName(String albumName);
}
