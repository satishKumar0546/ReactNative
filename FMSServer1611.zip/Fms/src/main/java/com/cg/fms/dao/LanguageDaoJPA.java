package com.cg.fms.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.fms.domain.Language;

public interface LanguageDaoJPA extends JpaRepository<Language, Integer> {
	Language findByLanguageName(String languageName);
}
