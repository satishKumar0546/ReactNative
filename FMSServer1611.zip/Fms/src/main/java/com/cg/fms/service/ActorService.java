package com.cg.fms.service;

import java.util.List;

import com.cg.fms.domain.Actor;
import com.cg.fms.domain.Status;

public interface ActorService {
	Status modifyActor(Actor actor);
	List<Actor> findActors(String firstName, String lastName);
	Status addActor(Actor actor);
	List<Actor> findAll();
	Actor find(int id);
	List<Actor> findActorsPrecise(String firstName, String lastName);
}
